#LAMMPS
export OMP_NUM_THREADS=8 
lmp -in diffusion.in > run.out

